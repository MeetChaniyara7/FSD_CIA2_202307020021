const API = 'http://localhost:5000/api';

function showTab(tab) {
  const isLogin = tab === 'login';
  document.getElementById('loginPane').classList.toggle('hidden', !isLogin);
  document.getElementById('registerPane').classList.toggle('hidden', isLogin);
  document.querySelectorAll('.tab-btn').forEach((b, i) =>
    b.classList.toggle('active', isLogin ? i === 0 : i === 1)
  );
}

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  const msg = document.getElementById('loginMsg');
  msg.className = 'auth-msg';

  const btn = e.target.querySelector('button');
  btn.textContent = 'Signing in...';
  btn.disabled = true;

  try {
    const res = await fetch(`${API}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (res.ok) {
      localStorage.setItem('token', data.token);
      localStorage.setItem('name', data.name);
      localStorage.setItem('studentId', data.studentId);
      localStorage.setItem('email', email);
      window.location.href = 'dashboard.html';
    } else {
      msg.className = 'auth-msg error';
      msg.textContent = data.message || 'Login failed. Please try again.';
    }
  } catch {
    msg.className = 'auth-msg error';
    msg.textContent = 'Cannot connect to server. Make sure backend is running.';
  }

  btn.textContent = 'Sign In →';
  btn.disabled = false;
});

document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;
  const msg = document.getElementById('registerMsg');
  msg.className = 'auth-msg';

  if (password.length < 6) {
    msg.className = 'auth-msg error';
    msg.textContent = 'Password must be at least 6 characters.';
    return;
  }

  const btn = e.target.querySelector('button');
  btn.textContent = 'Creating account...';
  btn.disabled = true;

  try {
    const res = await fetch(`${API}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    if (res.ok) {
      msg.className = 'auth-msg success';
      msg.textContent = `✓ Account created! Your ID: ${data.studentId}. Please sign in.`;
      e.target.reset();
      setTimeout(() => showTab('login'), 2000);
    } else {
      msg.className = 'auth-msg error';
      msg.textContent = data.message || 'Registration failed.';
    }
  } catch {
    msg.className = 'auth-msg error';
    msg.textContent = 'Cannot connect to server. Make sure backend is running.';
  }

  btn.textContent = 'Create Account →';
  btn.disabled = false;
});