const API = 'http://localhost:5000/api';
const token = localStorage.getItem('token');
if (!token) window.location.href = 'index.html';

document.getElementById('welcomeMsg').textContent = `Welcome, ${localStorage.getItem('name')}`;

function logout() {
  localStorage.clear();
  window.location.href = 'index.html';
}

async function fetchCourses() {
  const res = await fetch(`${API}/courses`, { headers: { Authorization: `Bearer ${token}` } });
  const courses = await res.json();
  const tbody = document.querySelector('#coursesTable tbody');
  tbody.innerHTML = '';
  courses.forEach(c => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${c.code}</td><td>${c.title}</td><td>${c.instructor}</td><td>${c.credits}</td>
      <td><button class="enroll-btn" onclick="enroll('${c._id}')">Enroll</button></td>`;
    tbody.appendChild(tr);
  });
}

async function fetchEnrollments() {
  const res = await fetch(`${API}/enrollments/mine`, { headers: { Authorization: `Bearer ${token}` } });
  const enrollments = await res.json();
  const tbody = document.querySelector('#enrollmentsTable tbody');
  tbody.innerHTML = '';
  enrollments.forEach(e => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${e.course.code}</td><td>${e.course.title}</td><td>${e.course.credits}</td>
      <td><button class="drop-btn" onclick="drop('${e._id}')">Drop</button></td>`;
    tbody.appendChild(tr);
  });
}

async function enroll(courseId) {
  const res = await fetch(`${API}/enrollments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify({ courseId })
  });
  const data = await res.json();
  alert(res.ok ? 'Enrolled successfully!' : data.message);
  if (res.ok) fetchEnrollments();
}

async function drop(enrollmentId) {
  if (!confirm('Drop this course?')) return;
  await fetch(`${API}/enrollments/${enrollmentId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });
  fetchEnrollments();
}

fetchCourses();
fetchEnrollments();