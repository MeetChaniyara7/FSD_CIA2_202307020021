const API = 'http://localhost:5000/api';
const token = localStorage.getItem('token');
if (!token) window.location.href = 'index.html';

// ── State ──
let allCourses = [];
let myEnrollments = [];
let pendingEnrollCourseId = null;

const COLORS = ['color-blue','color-green','color-amber','color-purple','color-red'];
const SCHEDULE_TIMES = ['09:00','10:00','11:00','12:00','14:00','15:00','16:00'];
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday'];

// ── Init ──
function init() {
  const name = localStorage.getItem('name') || 'Student';
  const sid = localStorage.getItem('studentId') || '—';
  const email = localStorage.getItem('email') || '';
  const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);

  document.getElementById('sidebarName').textContent = name;
  document.getElementById('sidebarId').textContent = sid;
  document.getElementById('sidebarAvatar').textContent = initials;
  document.getElementById('profileName').textContent = name;
  document.getElementById('profileStudentId').textContent = sid;
  document.getElementById('profileEmail').textContent = email;
  document.getElementById('profileAvatar').textContent = initials;

  fetchCourses();
  fetchEnrollments();
}

// ── Navigation ──
const pageMeta = {
  dashboard:   { title: 'Dashboard', sub: 'Your academic overview' },
  courses:     { title: 'Course Catalog', sub: 'Browse and enroll in available courses' },
  enrollments: { title: 'My Enrollments', sub: 'Courses registered this semester' },
  schedule:    { title: 'Class Schedule', sub: 'Spring Semester 2026 — weekly timetable' },
  profile:     { title: 'My Profile', sub: 'Your academic & personal information' },
  grades:      { title: 'Grades & Transcript', sub: 'Semester-wise academic performance' },
};

function showPage(id, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + id).classList.add('active');
  if (el) el.classList.add('active');

  const meta = pageMeta[id] || { title: id, sub: '' };
  document.getElementById('pageTitle').textContent = meta.title;
  document.getElementById('pageSubtitle').textContent = meta.sub;

  if (id === 'schedule') buildSchedule();
}

// ── Toast ──
function toast(msg, type = 'info') {
  const icons = { success: '✅', error: '❌', info: 'ℹ️' };
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span class="toast-icon">${icons[type]}</span><span>${msg}</span>`;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

// ── Modal ──
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// ── Fetch Courses ──
async function fetchCourses() {
  try {
    const res = await fetch(`${API}/courses`, { headers: { Authorization: `Bearer ${token}` } });
    allCourses = await res.json();
    renderCourses(allCourses);
    document.getElementById('stat-available').textContent = allCourses.length;
  } catch {
    toast('Failed to load courses', 'error');
  }
}

// ── Render Course Cards ──
function renderCourses(courses) {
  const grid = document.getElementById('courseGrid');
  if (!courses.length) {
    grid.innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><p>No courses found</p></div>';
    return;
  }

  const enrolledIds = myEnrollments.map(e => e.course?._id || e.course);

  grid.innerHTML = courses.map((c, i) => {
    const enrolled = enrolledIds.includes(c._id);
    const filled = Math.floor(Math.random() * c.seats);
    const pct = Math.round((filled / c.seats) * 100);
    const fillClass = pct > 80 ? 'full' : pct > 60 ? 'warn' : '';
    const color = COLORS[i % COLORS.length];
    const dept = c.code.replace(/[0-9]/g,'');

    return `
    <div class="course-card ${color}">
      <div class="course-code">${c.code}</div>
      <div class="course-title-card">${c.title}</div>
      <div class="course-instructor">👤 ${c.instructor || 'TBA'}</div>
      <div class="seats-bar"><div class="seats-fill ${fillClass}" style="width:${pct}%"></div></div>
      <div class="course-meta">
        <span class="meta-pill">🎓 ${c.credits} Credits</span>
        <span class="meta-pill">💺 ${c.seats - filled} seats left</span>
        <span class="meta-pill">🏛 ${dept}</span>
      </div>
      <div style="font-size:12px;color:var(--text-secondary);margin-bottom:14px">${c.description || 'No description provided.'}</div>
      <div class="course-footer">
        <span class="badge ${enrolled ? 'badge-green' : 'badge-blue'}">${enrolled ? '✓ Enrolled' : 'Available'}</span>
        ${enrolled
          ? `<button class="btn btn-ghost btn-sm" disabled>Enrolled</button>`
          : `<button class="btn btn-accent btn-sm" onclick="openEnrollModal('${c._id}')">Enroll →</button>`
        }
      </div>
    </div>`;
  }).join('');
}

// ── Filter Courses ──
function filterCourses() {
  const q = document.getElementById('courseSearch').value.toLowerCase();
  const dept = document.getElementById('deptFilter').value;
  const credits = document.getElementById('creditFilter').value;

  const filtered = allCourses.filter(c => {
    const matchQ = !q || c.title.toLowerCase().includes(q) || c.code.toLowerCase().includes(q) || (c.instructor||'').toLowerCase().includes(q);
    const matchDept = !dept || c.code.startsWith(dept);
    const matchCredits = !credits || c.credits == credits;
    return matchQ && matchDept && matchCredits;
  });
  renderCourses(filtered);
}

// ── Fetch Enrollments ──
async function fetchEnrollments() {
  try {
    const res = await fetch(`${API}/enrollments/mine`, { headers: { Authorization: `Bearer ${token}` } });
    myEnrollments = await res.json();
    renderEnrollments();
    updateDashboard();
  } catch {
    toast('Failed to load enrollments', 'error');
  }
}

// ── Render Enrollments Table ──
function renderEnrollments() {
  const badge = document.getElementById('enrollBadge');
  badge.textContent = myEnrollments.length;

  const tbody = document.getElementById('enrollTable');
  if (!myEnrollments.length) {
    tbody.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="empty-icon">📭</div><p>You haven't enrolled in any courses yet. <a href="#" onclick="showPage('courses',null)" style="color:var(--accent)">Browse courses →</a></p></div></td></tr>`;
    return;
  }

  const colors = ['badge-blue','badge-green','badge-amber','badge-purple','badge-red'];
  tbody.innerHTML = myEnrollments.map((e, i) => {
    const c = e.course || {};
    const dept = (c.code || '').replace(/[0-9]/g,'');
    return `
    <tr>
      <td><span style="font-family:'JetBrains Mono',monospace;color:var(--accent);font-size:13px">${c.code || '—'}</span></td>
      <td style="font-weight:600">${c.title || '—'}</td>
      <td>${c.instructor || 'TBA'}</td>
      <td><span class="${colors[i%colors.length]} badge">${c.credits || 0} cr</span></td>
      <td><span class="badge badge-purple">${dept || 'GEN'}</span></td>
      <td><span class="badge badge-green">● Enrolled</span></td>
      <td>
        <button class="btn btn-danger btn-sm" onclick="dropCourse('${e._id}', '${c.title}')">Drop</button>
      </td>
    </tr>`;
  }).join('');
}

// ── Update Dashboard Stats ──
function updateDashboard() {
  document.getElementById('stat-enrolled').textContent = myEnrollments.length;
  const totalCredits = myEnrollments.reduce((sum, e) => sum + (e.course?.credits || 0), 0);
  document.getElementById('stat-credits').textContent = totalCredits;

  const dashTbody = document.getElementById('dashEnrollTable');
  if (!myEnrollments.length) {
    dashTbody.innerHTML = `<tr><td colspan="3"><div class="empty-state" style="padding:30px"><div class="empty-icon">📭</div><p>No enrollments yet</p></div></td></tr>`;
    return;
  }
  dashTbody.innerHTML = myEnrollments.slice(0,5).map(e => {
    const c = e.course || {};
    return `<tr>
      <td>
        <div style="font-weight:600;font-size:13px">${c.title || '—'}</div>
        <div style="font-size:11px;color:var(--text-muted);font-family:monospace">${c.code || ''}</div>
      </td>
      <td><span class="badge badge-blue">${c.credits || 0} cr</span></td>
      <td><span class="badge badge-green">Enrolled</span></td>
    </tr>`;
  }).join('');
}

// ── Open Enroll Modal ──
function openEnrollModal(courseId) {
  const course = allCourses.find(c => c._id === courseId);
  if (!course) return;
  pendingEnrollCourseId = courseId;

  document.getElementById('modalCourseInfo').innerHTML = `
    <div style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--accent);margin-bottom:6px">${course.code}</div>
    <div style="font-size:15px;font-weight:700;margin-bottom:4px">${course.title}</div>
    <div style="font-size:13px;color:var(--text-secondary);margin-bottom:10px">👤 ${course.instructor || 'TBA'}</div>
    <div style="display:flex;gap:10px">
      <span class="badge badge-blue">🎓 ${course.credits} Credits</span>
      <span class="badge badge-green">💺 ${course.seats} Seats</span>
    </div>`;
  openModal('enrollModal');
}

// ── Confirm Enroll ──
async function confirmEnroll() {
  if (!pendingEnrollCourseId) return;
  try {
    const res = await fetch(`${API}/enrollments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ courseId: pendingEnrollCourseId })
    });
    const data = await res.json();
    closeModal('enrollModal');
    if (res.ok) {
      toast('Successfully enrolled in course!', 'success');
      await fetchEnrollments();
      renderCourses(allCourses);
    } else {
      toast(data.message || 'Enrollment failed', 'error');
    }
  } catch {
    toast('Server error. Try again.', 'error');
  }
  pendingEnrollCourseId = null;
}

// ── Drop Course ──
async function dropCourse(enrollmentId, title) {
  if (!confirm(`Drop "${title}"? This action cannot be undone.`)) return;
  try {
    await fetch(`${API}/enrollments/${enrollmentId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });
    toast(`Dropped "${title}" successfully`, 'success');
    await fetchEnrollments();
    renderCourses(allCourses);
  } catch {
    toast('Failed to drop course', 'error');
  }
}

// ── Build Schedule ──
function buildSchedule() {
  const grid = document.getElementById('scheduleGrid');
  const enrolled = myEnrollments.map(e => e.course).filter(Boolean);

  const scheduleMap = {};
  enrolled.forEach((c, i) => {
    const day = DAYS[i % 5];
    const time = SCHEDULE_TIMES[i % SCHEDULE_TIMES.length];
    const key = `${day}-${time}`;
    scheduleMap[key] = c;
  });

  let html = `
    <div class="sch-cell sch-header">Time</div>
    <div class="sch-cell sch-header">Monday</div>
    <div class="sch-cell sch-header">Tuesday</div>
    <div class="sch-cell sch-header">Wednesday</div>
    <div class="sch-cell sch-header">Thursday</div>
    <div class="sch-cell sch-header">Friday</div>`;

  SCHEDULE_TIMES.forEach(time => {
    html += `<div class="sch-cell sch-time">${time}</div>`;
    DAYS.forEach(day => {
      const c = scheduleMap[`${day}-${time}`];
      html += `<div class="sch-cell">${c
        ? `<div class="sch-class" style="background:var(--accent-soft);color:var(--accent)">
             <div style="font-weight:700;font-size:10px;margin-bottom:2px">${c.code}</div>
             <div style="font-size:10px;opacity:0.8">${c.title?.slice(0,18)}...</div>
           </div>`
        : ''}</div>`;
    });
  });

  grid.innerHTML = html;
}

// ── Logout ──
function logout() {
  localStorage.clear();
  window.location.href = 'index.html';
}

// Close modal on overlay click
document.getElementById('enrollModal').addEventListener('click', function(e) {
  if (e.target === this) closeModal('enrollModal');
});

init();