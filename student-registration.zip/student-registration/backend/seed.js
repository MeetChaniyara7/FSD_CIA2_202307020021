/**
 * Seed Script — run once to populate dummy data
 * Usage: node seed.js
 */
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const Student = require('./models/Student');
const Course  = require('./models/Course');
const Enrollment = require('./models/Enrollment');

const courses = [
  { title: 'Data Structures & Algorithms', code: 'CS501', description: 'Arrays, linked lists, trees, graphs, sorting & searching algorithms.', instructor: 'Dr. Rajesh Kumar', credits: 4, seats: 60 },
  { title: 'Database Management Systems', code: 'CS502', description: 'Relational model, SQL, normalization, transactions and NoSQL databases.', instructor: 'Prof. Anita Sharma', credits: 3, seats: 55 },
  { title: 'Operating Systems', code: 'CS503', description: 'Process management, memory, file systems, synchronization and scheduling.', instructor: 'Dr. Suresh Patel', credits: 3, seats: 50 },
  { title: 'Computer Networks', code: 'CS504', description: 'OSI model, TCP/IP, routing, switching, and network security fundamentals.', instructor: 'Prof. Meera Nair', credits: 3, seats: 45 },
  { title: 'Machine Learning', code: 'CS505', description: 'Supervised & unsupervised learning, neural networks, model evaluation.', instructor: 'Dr. Arjun Verma', credits: 4, seats: 40 },
  { title: 'Web Technologies', code: 'IT501', description: 'HTML5, CSS3, JavaScript, Node.js, REST APIs and full-stack development.', instructor: 'Prof. Priya Singh', credits: 3, seats: 50 },
  { title: 'Cloud Computing', code: 'IT502', description: 'AWS, Azure, GCP, virtualization, microservices and serverless architecture.', instructor: 'Dr. Kiran Shah', credits: 3, seats: 45 },
  { title: 'Cyber Security', code: 'IT503', description: 'Cryptography, network security, ethical hacking, and security protocols.', instructor: 'Prof. Ravi Menon', credits: 3, seats: 40 },
  { title: 'Artificial Intelligence', code: 'CS506', description: 'Search algorithms, knowledge representation, reasoning, and NLP basics.', instructor: 'Dr. Deepa Iyer', credits: 4, seats: 50 },
  { title: 'Software Engineering', code: 'CS507', description: 'SDLC, Agile, design patterns, testing, and project management.', instructor: 'Prof. Vinod Bhat', credits: 3, seats: 55 },
  { title: 'Digital Signal Processing', code: 'EC501', description: 'Signals, Fourier transform, filters, and DSP applications.', instructor: 'Dr. Shalini Rao', credits: 3, seats: 35 },
  { title: 'Embedded Systems', code: 'EC502', description: 'Microcontrollers, RTOS, IoT hardware programming, and interfacing.', instructor: 'Prof. Arun Joshi', credits: 3, seats: 30 },
  { title: 'Business Analytics', code: 'MBA501', description: 'Data-driven decision making, dashboards, and analytical tools.', instructor: 'Dr. Neha Gupta', credits: 2, seats: 60 },
  { title: 'Entrepreneurship & Innovation', code: 'MBA502', description: 'Startup ecosystem, business models, funding, and lean methodology.', instructor: 'Prof. Amit Desai', credits: 2, seats: 60 },
  { title: 'Engineering Mathematics', code: 'MA501', description: 'Linear algebra, calculus, probability, and statistics for engineers.', instructor: 'Dr. Kavitha Pillai', credits: 4, seats: 70 },
];

const students = [
  { name: 'Aarav Mehta',   email: 'aarav@university.edu',   password: 'pass123' },
  { name: 'Priya Sharma',  email: 'priya@university.edu',   password: 'pass123' },
  { name: 'Rohan Patel',   email: 'rohan@university.edu',   password: 'pass123' },
  { name: 'Sneha Nair',    email: 'sneha@university.edu',   password: 'pass123' },
  { name: 'Arjun Singh',   email: 'arjun@university.edu',   password: 'pass123' },
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ MongoDB connected');

    // Clear existing data
    await Course.deleteMany({});
    await Student.deleteMany({});
    await Enrollment.deleteMany({});
    console.log('🗑  Cleared existing data');

    // Insert courses
    const insertedCourses = await Course.insertMany(courses);
    console.log(`📚 Inserted ${insertedCourses.length} courses`);

    // Insert students with hashed passwords
    const insertedStudents = [];
    for (const s of students) {
      const hashed = await bcrypt.hash(s.password, 10);
      const studentId = 'STU' + Date.now() + Math.floor(Math.random()*100);
      const student = await Student.create({ name: s.name, email: s.email, password: hashed, studentId });
      insertedStudents.push(student);
    }
    console.log(`👩‍🎓 Inserted ${insertedStudents.length} students`);

    // Create some enrollments
    const enrollments = [
      { student: insertedStudents[0]._id, course: insertedCourses[0]._id },
      { student: insertedStudents[0]._id, course: insertedCourses[4]._id },
      { student: insertedStudents[0]._id, course: insertedCourses[5]._id },
      { student: insertedStudents[1]._id, course: insertedCourses[1]._id },
      { student: insertedStudents[1]._id, course: insertedCourses[2]._id },
      { student: insertedStudents[2]._id, course: insertedCourses[0]._id },
      { student: insertedStudents[2]._id, course: insertedCourses[8]._id },
      { student: insertedStudents[3]._id, course: insertedCourses[3]._id },
      { student: insertedStudents[4]._id, course: insertedCourses[6]._id },
    ];
    await Enrollment.insertMany(enrollments);
    console.log(`✅ Inserted ${enrollments.length} enrollments`);

    console.log('\n🎉 Database seeded successfully!\n');
    console.log('──────────────────────────────────────');
    console.log('Demo student accounts (password: pass123)');
    console.log('──────────────────────────────────────');
    insertedStudents.forEach(s => console.log(`  📧 ${s.email}  |  ID: ${s.studentId}`));
    console.log('──────────────────────────────────────\n');

    process.exit(0);
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    process.exit(1);
  }
}

seed();