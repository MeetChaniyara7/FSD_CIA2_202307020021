const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
  title:       { type: String, required: true },
  code:        { type: String, required: true, unique: true },
  description: { type: String },
  instructor:  { type: String },
  credits:     { type: Number },
  seats:       { type: Number, default: 30 },
}, { timestamps: true });

module.exports = mongoose.model('Course', courseSchema);