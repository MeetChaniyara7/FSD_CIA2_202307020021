const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
  course:  { type: mongoose.Schema.Types.ObjectId, ref: 'Course', required: true },
  status:  { type: String, enum: ['enrolled', 'dropped'], default: 'enrolled' },
}, { timestamps: true });

module.exports = mongoose.model('Enrollment', enrollmentSchema);