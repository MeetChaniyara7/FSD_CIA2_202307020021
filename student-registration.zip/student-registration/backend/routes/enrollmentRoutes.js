const express = require('express');
const router = express.Router();
const Enrollment = require('../models/Enrollment');
const protect = require('../middleware/authMiddleware');

// Enroll in a course
router.post('/', protect, async (req, res) => {
  try {
    const existing = await Enrollment.findOne({ student: req.user.id, course: req.body.courseId });
    if (existing) return res.status(400).json({ message: 'Already enrolled' });
    const enrollment = await Enrollment.create({ student: req.user.id, course: req.body.courseId });
    res.status(201).json(enrollment);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Get my enrollments
router.get('/mine', protect, async (req, res) => {
  const enrollments = await Enrollment.find({ student: req.user.id }).populate('course');
  res.json(enrollments);
});

// Drop a course
router.delete('/:id', protect, async (req, res) => {
  await Enrollment.findByIdAndDelete(req.params.id);
  res.json({ message: 'Dropped successfully' });
});

module.exports = router;