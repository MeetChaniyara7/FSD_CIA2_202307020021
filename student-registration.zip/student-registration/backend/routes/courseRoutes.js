const express = require('express');
const router = express.Router();
const Course = require('../models/Course');
const protect = require('../middleware/authMiddleware');

router.get('/', protect, async (req, res) => {
  const courses = await Course.find();
  res.json(courses);
});

router.post('/', protect, async (req, res) => {
  try {
    const course = await Course.create(req.body);
    res.status(201).json(course);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.delete('/:id', protect, async (req, res) => {
  await Course.findByIdAndDelete(req.params.id);
  res.json({ message: 'Course deleted' });
});

module.exports = router;