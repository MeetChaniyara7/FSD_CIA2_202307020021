const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Student = require('../models/Student');

// Register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const hashed = await bcrypt.hash(password, 10);
    const studentId = 'STU' + Date.now();
    const student = await Student.create({ name, email, password: hashed, studentId });
    res.status(201).json({ message: 'Registered successfully', studentId: student.studentId });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const student = await Student.findOne({ email });
    if (!student || !(await bcrypt.compare(password, student.password)))
      return res.status(401).json({ message: 'Invalid credentials' });
    const token = jwt.sign({ id: student._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, name: student.name, studentId: student.studentId });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;